<?php

namespace Wishlist\Model;

abstract class Model
{

}