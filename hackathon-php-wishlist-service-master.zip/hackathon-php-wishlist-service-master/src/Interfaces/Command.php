<?php

namespace Wishlist\Interfaces;

interface Command
{
    public function execute();
}