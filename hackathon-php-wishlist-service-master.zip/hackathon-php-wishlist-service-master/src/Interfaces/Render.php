<?php

namespace Wishlist\Interfaces;

interface Render
{
    public function render();
}