<?php

namespace Wishlist\Interfaces;

interface Exception
{
    public function __construct($message);
}