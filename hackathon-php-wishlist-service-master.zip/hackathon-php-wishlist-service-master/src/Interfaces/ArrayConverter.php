<?php

namespace Wishlist\Interfaces;

interface ArrayConverter
{
    public function convert($value);
}