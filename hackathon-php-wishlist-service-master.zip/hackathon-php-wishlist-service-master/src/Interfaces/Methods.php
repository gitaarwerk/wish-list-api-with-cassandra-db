<?php

namespace Wishlist\Interfaces;

interface Methods
{
    public function get();

    public function post();

    public function delete();

    public function put();

    public function update();
}