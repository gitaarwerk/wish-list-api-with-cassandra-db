<?php

namespace Wishlist\Util;

abstract class Statuscode
{
    const NOT_FOUND = 404;
    const METHOD_NOT_ALLOWED = 405;
    const NOT_IMPLEMENTED = 501;
}