<?php

define("CHARACTER_ENCODING", "UTF-8");

define("SUPPORTED_CONTENT_TYPES", "json_hal, json, xml");
define("DEFAULT_CONTENT_TYPES", "json");

define("DATABASE_NAME", "wishlistdb");
define("DATABASE_TABLE", "wishlist");

define("DEVELOPMENT", true); // bool;